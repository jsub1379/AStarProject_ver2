#include "System/System.h"
#include "Engine.h"
int main()
{
	System aStarsSystem;
	aStarsSystem.Run();
}